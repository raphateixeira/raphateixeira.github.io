---
title: A minimal layout page
layout: minimal
parent: Layout
has_children: true
---

# A minimal layout page

This page illustrates the built-in layout `minimal`.

One of its child pages also uses the minimal layout; the other child pages uses the default layout.
