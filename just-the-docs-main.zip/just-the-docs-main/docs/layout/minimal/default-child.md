---
title: Default layout child page
layout: default
parent: A minimal layout page 
grand_parent: Layout
---

This is a child page that uses the same minimal layout as its parent page.
